﻿using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using RaceDay.Mvc.Models;

namespace RaceDay.Mvc.Controllers
{
    public class HomeController : Controller
    {
        private readonly HttpClient _httpClient;
        private readonly IConfiguration _configuration;

        public HomeController(IHttpClientFactory httpClientFactory, IConfiguration configuration)
        {
            _httpClient = httpClientFactory.CreateClient();
            _configuration = configuration;
        }

        public async Task<IActionResult> Index()
        {
            var baseUrl = _configuration["ApiSettings:BaseUrl"] ?? "http://localhost:5150/";
            List<RaceEventDto> events = new();

            try
            {
                var response = await _httpClient.GetAsync($"{baseUrl.TrimEnd('/')}/api/events");
                if (response.IsSuccessStatusCode)
                {
                    var stream = await response.Content.ReadAsStreamAsync();
                    events = await JsonSerializer.DeserializeAsync<List<RaceEventDto>>(
                        stream,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true }
                    ) ?? new();
                }
            }
            catch
            {
                // Fallback if API is offline during design
            }

            return View(events);
        }
    }
}